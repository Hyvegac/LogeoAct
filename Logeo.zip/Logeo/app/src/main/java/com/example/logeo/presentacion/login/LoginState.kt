package com.example.logeo.presentacion.login


import androidx.annotation.StringRes

data class LoginState (
    val emailValue :String = "",
    val passwordValue : String ="",
    val successLogin: Boolean = false,
    val displayProgressBar: Boolean = false,
    @StringRes val errorMessages: Int? = null
)