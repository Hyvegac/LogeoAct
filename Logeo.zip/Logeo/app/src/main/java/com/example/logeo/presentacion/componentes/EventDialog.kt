package com.example.logeo.presentacion.componentes

import androidx.annotation.StringRes
import androidx.compose.compiler.plugins.kotlin.ComposeErrorMessages
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun EventDialong (modifier: Modifier = Modifier,
                  onDismiss : (()->Unit) ? = null,
                  @StringRes errorMessages: Int
){
    AlertDialog(
        modifier = Modifier
            .background(Color.DarkGray)
            .padding(16.dp),
        onDismissRequest = { onDismiss?.invoke() },
        title = {
            Text(
                text = "Error",
                style = TextStyle(
                    color = MaterialTheme.colors.onSurface,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
            ) },//Fin del titulo
        text = {
            Text(
                text = LocalContext.current.getString(errorMessages),
                style = TextStyle(
                    color = MaterialTheme.colors.onSurface,
                    fontSize = 16.sp
                )
            )},//Fin del text
        buttons = {
            Row(modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
                horizontalArrangement = Arrangement.End
            ) {
                TextButton(onClick = { onDismiss?.invoke() }) {
                    Text(
                        text = "Aceptar",
                        style = MaterialTheme.typography.button
                    )//Fin del text
                }//Fin del text button
            }//Fin del row
        }//Fin del buttons
    )//Fin del alert dialog
}//Fin del event dialog
