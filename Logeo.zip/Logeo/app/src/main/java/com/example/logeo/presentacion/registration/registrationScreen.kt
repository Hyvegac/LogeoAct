package com.example.logeo.presentacion.registration
import android.app.AlertDialog
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.ClickableText
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.example.logeo.navegation.AppNav
import com.example.logeo.presentacion.componentes.EventDialong
import com.example.logeo.presentacion.componentes.RoundedButton
import com.example.logeo.presentacion.componentes.SocialMediaButton
import com.example.logeo.presentacion.componentes.TransparentTextField

@Composable
fun RegistrationScreen(navController: NavHostController,
                       state: RegisterState,
                       onRegister : (String,String,String,String,String) ->Unit,
                       onBack: ()-> Unit,
                       onDismissDialog: ()->Unit
) {
    val nameValue = remember { mutableStateOf("") }
    val emailValue = remember { mutableStateOf("") }
    val phoneNumber = remember { mutableStateOf("") }
    val passValue = remember { mutableStateOf("") }
    val confirmPassword = remember { mutableStateOf("") }
    var passwordVisibility by remember { mutableStateOf(false) }
    var confirmPasswordVisibility by remember { mutableStateOf(false) }
    val focusManager = LocalFocusManager.current
    Box(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState())) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = {
                    onBack()
                }) {
                    Icon(imageVector = Icons.Default.ArrowBack , contentDescription = "Regresar al login", tint = MaterialTheme.colors.primary)
                }
                Text(text = "Crear una cuenta", style = MaterialTheme.typography.h6.copy(
                    color = MaterialTheme.colors.primary
                ))
            }//Fin de la fila inicial
            Column( modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                TransparentTextField(
                    textFieldValue = nameValue ,
                    textLabel = "Nombre",
                    keyboardType = KeyboardType.Text,
                    keyboardActions = KeyboardActions(
                        onNext = {
                            focusManager.moveFocus(FocusDirection.Down)
                        }
                    ),
                    imeAction = ImeAction.Next,
                )//Texto Nombre
                TransparentTextField(
                    textFieldValue = emailValue ,
                    textLabel = "Email",
                    keyboardType = KeyboardType.Email,
                    keyboardActions = KeyboardActions(
                        onNext = {
                            focusManager.moveFocus(FocusDirection.Down)
                        }
                    ),
                    imeAction = ImeAction.Next
                )//Texto Correo
                TransparentTextField(
                    textFieldValue = phoneNumber ,
                    textLabel = "Telefono",
                    maxChar = 10,
                    keyboardType = KeyboardType.Phone,
                    keyboardActions = KeyboardActions(
                        onNext = {
                            focusManager.moveFocus(FocusDirection.Down)
                        }
                    ),
                    imeAction = ImeAction.Next
                )//Texto Telefono
                TransparentTextField(
                    textFieldValue = passValue ,
                    textLabel = "Contraseña",
                    keyboardType = KeyboardType.Password,
                    keyboardActions = KeyboardActions(
                        onNext = {
                            focusManager.moveFocus(FocusDirection.Down)
                        }
                    ),
                    imeAction = ImeAction.Next,
                    trailingIcon = {
                        IconButton(onClick = {
                            passwordVisibility = !passwordVisibility
                        }) {
                            Icon(
                                imageVector = if (passwordVisibility){
                                    Icons.Default.Visibility
                                } else {
                                    Icons.Default.VisibilityOff
                                },
                                contentDescription = "Toggle" )
                        }
                    },//Fin del trailing
                    visualTransformation = if (passwordVisibility){
                        VisualTransformation.None
                    }else{
                        PasswordVisualTransformation()
                    }
                )//Fin del Tranparent Texto Clave
                TransparentTextField(
                    textFieldValue = confirmPassword ,
                    textLabel = "Confirme su contraseña",
                    keyboardType = KeyboardType.Password,
                    keyboardActions = KeyboardActions(
                        onDone = {
                            focusManager.clearFocus()
                            onRegister(
                                nameValue.value,
                                emailValue.value,
                                phoneNumber.value,
                                passValue.value,
                                confirmPassword.value
                            )
                        }
                    ),
                    imeAction = ImeAction.Done
                )//Texto para confirmar Clave
                Spacer(modifier = Modifier.height(16.dp) )//Espacio
                RoundedButton(
                    modifier = Modifier.clickable {
                    //TODO{}
                    },
                    text = "Sign Up",
                    displayProgressBar = false,
                    onClick = {
                        onRegister(
                            nameValue.value,
                            emailValue.value,
                            phoneNumber.value,
                            passValue.value,
                            confirmPassword.value
                        )
                    }
                ) // Fin Boton de sing up
                ClickableText(text = buildAnnotatedString {
                    append("Already have Account ")
                    withStyle(
                        style = SpanStyle(
                            color = MaterialTheme.colors.primary,
                            fontWeight = FontWeight.Bold
                        )
                    )//Fin del withStyle
                    {
                        append("Log In")
                    }
                }, onClick = {
                    onBack()
                })//Already have a account
            }//Fin de la columna interior
            Spacer(modifier = Modifier.height(16.dp) )//Espacio
            Column( verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Row (
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ){
                    Divider(
                        modifier = Modifier.width(24.dp),
                        thickness = 1.dp,
                        color = Color.Gray
                    )//Linea divisoria
                    Text(
                        modifier = Modifier.padding(8.dp),
                        text = "OR",
                        color = Color.Blue
                    )
                    Divider(
                        modifier = Modifier.width(24.dp),
                        thickness = 1.dp,
                        color = Color.Gray
                    )//Linea divisoria
                    //Botones Adicionales para redes sociales
                }//Fin de la fila
                Text(
                    modifier = Modifier
                        .padding(8.dp)
                        .fillMaxWidth(),
                    text = "Login With",
                    style = MaterialTheme.typography.body1.copy(MaterialTheme.colors.primary),
                    textAlign = TextAlign.Center
                )
            }//Fin de la columna interna
            Spacer(modifier = Modifier.height(16.dp))
            Column(modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                horizontalAlignment = Alignment.CenterHorizontally) {
                //TODO {Creamos un nuevo componente para los botones}
                SocialMediaButton(
                    text = "Login With Facebook",
                    onClick = { /*TODO*/ },
                    socialMediaColor = MaterialTheme.colors.secondary
                )
                SocialMediaButton(
                    text = "Login With Gmail" ,
                    onClick = { /*TODO*/ },
                    socialMediaColor = MaterialTheme.colors.primary
                )
                SocialMediaButton(
                    text = "Login With Instagram" ,
                    onClick = { /*TODO*/ },
                    socialMediaColor = MaterialTheme.colors.error
                )
            }//Fin de la columna contenedora de redes sociales
        }//Fin de la columna Exterior
        if (state.errorMessages !=null){
            EventDialong(errorMessages = state.errorMessages, onDismiss = onDismissDialog)
        }
    }//Fin del Box
}//Fin de la funcion principal

