package com.example.logeo.navegation


import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.logeo.navegation.AppNav.Login

import com.example.logeo.presentacion.login.LoginScreen
import com.example.logeo.presentacion.login.LoginViewModel
import com.example.logeo.presentacion.registration.RegisterViewModel
import com.example.logeo.presentacion.registration.RegistrationScreen
import com.example.logeo.screen.HomeScreen


@Composable
fun AppNavegation(){
    val navController = rememberNavController()
    NavHost(
        navController = navController,
        startDestination = AppNav.Login.route
    )
    {
        val viewModel = LoginViewModel()
        composable(route = AppNav.Login.route){
//            val viewModel = LoginViewModel()
            if (viewModel.state.value.successLogin){
                LaunchedEffect(key1 = Unit){
                    navController.navigate(AppNav.HomeScreen.createRoute(viewModel.state.value.emailValue)){
                        popUpTo(AppNav.Login.route){
                            inclusive = true
                        }
                    }
                }
            } else {
                LoginScreen(
                    navController,
                    state = viewModel.state.value,
                    onLogin = viewModel :: Login,
                    onNavigateToRegister = { navController.navigate(AppNav.Registration.route)},
                    onDismissDialog = viewModel :: hideErrorDialog
                )
            }
            LoginScreen(navController,
                state = viewModel.state.value,
                onLogin = viewModel :: Login,
                onNavigateToRegister = { navController.navigate(AppNav.Registration.route)},
                onDismissDialog = viewModel :: hideErrorDialog)
        }
        val viewModel2 = RegisterViewModel()
        composable(route = AppNav.Registration.route)
        {
//            val viewModel = RegisterViewModel()
            RegistrationScreen(navController,
                state = viewModel2.state.value,
                onRegister = viewModel2 :: register,
                onBack = {navController.popBackStack()},
                onDismissDialog = viewModel2 :: hideErrorDialog
            )
        }
        composable(
            route = AppNav.HomeScreen.route,
            arguments = listOf(navArgument("email"){
                type = NavType.StringType
            }
            )
        )
        {
            HomeScreen(navController, email = it.arguments?.getString("email")?: "" )
        }
    }
}