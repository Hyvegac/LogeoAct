package com.example.logeo.models

//import com.example.logeo.R
//
//var receta = listOf(
//    Receta(
//        nombre = "Pato parrilla al pipián",
//        preparacion = "Caliente un poco de aciete en una cacerola a fuego medio y sofría la cebolla, los dientes de ajo, la pimienta, el comino y la canela durante 10 minutos. Retire los ingredientes de la cacerola y licúelos con un poco de agua hasta obtener una salsa homogénea. Caliente un poco de aceite en una cacerola a fuego medio y sofría las especias licuadas durante un par de minutos. Licue los jitomates con el ajonjolí y añada esta mezcla a la cacerola. Incorpore el polvo de semillas de chile y reduzca a fuego lento hasta que la preparación espese. Agregue sal al gusto y reserve." ,
//        foto = R.drawable.pato
//    ),
//    Receta(
//        nombre = "Rosca de miel y especias",
//        preparacion = "Precaliente el horno a 180 ºC. Ponga sobre el fuego la miel hasta que se derrita; retírela del fuego, añádale la mantequilla y mézclela hasta que se funda. Bata esta preparación hasta que se enfríe. Añada entonces los huevos, uno a uno, hasta que todos los ingredientes estén bien incorporados. Mezcle las harinas con el polvo para hornear, la linaza, las especias y la sal. Integre poco a poco estos ingredientes a la preparación anterior, hasta que obtenga una masa de consistencia y textura homogéneas. Engrase y enharine un molde de rosca y vierta dentro la masa. Hornee durante 50 minutos o hasta que la rosca se dore, y que al introducirle un palillo en el centro, éste salga limpio. Saque la rosca del horno, déjela enfriar, desmóldela y sírvala.",
//        foto = R.drawable.rosca
//    ),
//    Receta(
//        nombre = "Tacos de quelites con requesón",
//        preparacion = "Ponga sobre el fuego la manteca o el aceite en un sartén grueso con tapa y sofría ligeramente la cebolla, el ajo y el chile. Añada los quelites y sal al gusto. Cuando los quelites comiencen a soltar líquido, tape el sartén y retírelos del fuego. Déjelos reposar durante algunos minutos. Comprima la mezcla de quelites para eliminar el exceso de líquido. Añada el requesón y el cilantro picado; mezcle y caliente de nuevo. Caliente las tortillas, ponga en el centro de cada una un poco de los quelites y forme los tacos. Sírvalos calientes acompañados con el pico de gallo o la salsa de su elección.",
//        foto = R.drawable.tacos
//    ),
//    Receta(
//        nombre = "Sacher vegano",
//        preparacion = "Mezcla en un tazón los ingredientes secos: la harina, el impulsor, el bicarbonato, el azúcar, la proteína de patata, el caca en polvo y la sal. Funde el aceite de coco a 40 °C. Añade el agua, el aceite de girasol, el aceite de coco y la vainilla, y amasa durante 5 minutos. Vierte el vinagre de manzana y mezcla con una lengua durante 1 minuto. Pon 315 g de masa de bizcocho en 2 aros de 20 cm. Hornea a 180 °C hasta que, al pincharla con un palillo, este salga limpio. Deje que se enfríe a temperatura ambiente y reserva en la nevera o el congelador de 6 a 12 horas." ,
//        foto = R.drawable.sacher
//    ),
//    Receta(
//        nombre = "Apple Pie",
//        preparacion = "Procese la harina, con la mitad de la mantequilla, el azúcar, la sal y la canela hasta obtener una mezcla arenosa. Incorpore la otra mitad de la mantequilla y añada el agua poco a poco hasta obtener una masa homogénea. Refrigere durante 15 minutos. Divida la masa en dos y extienda una parte entre dos papeles siliconados, con ayuda de un rodillo, hasta obtener un círculo de mayor tamaño que el molde a utilizar. Forre la base del molde de 25 centímetros de diámetro con la masa y recorte los excedentes. Extienda la masa restante de la misma manera y resérvela. Distribuya el Relleno de manzanas en el molde con masa, cubra con el círculo de masa restante y doble la orilla de ambas masas, sellándolas con la yema de sus dedos. Barnice la superficie de la tarta con leche y espolvoréela con suficiente Azúcar acanelada. Hornee la tarta a fuego indirecto entre 35 y 45 minutos. Retire del fuego, deje enfriar y sirva.",
//        foto = R.drawable.apple
//    ),
//    Receta(
//        nombre = "Atole de Arroz",
//        preparacion= "Cueza el arroz en el agua hasta que esté suave. Cuélelo y reserve. Caliente la leche en una olla y añada el arroz, el azúcar y la canela. Cueaza a fuego medio sin dejar de mover, entre 15 y 20 minutos o hasta que el atole espese. Rectifique la cantidad de azúcar y sirva caliente.",
//        foto = R.drawable.atole
//    ),
//    Receta(
//        nombre = "Chutney de mango",
//        preparacion = "Calienta en una olla a fuego medio el aceite o ghee y sofríe la cebolla hasta que tome una textura suave y se torne transparente. Agrega el resto de los ingredientes y cocina durante 20 minutos a fuego bajo, hasta que la fruta haya soltado su jugo, los sabores se incorporen y tenga una textura más espesa. Coloca en un frasco o recipiente hermético.",
//        foto = R.drawable.chutney
//    ),
//    Receta(
//        nombre = "Caldo de camaron",
//        preparacion = "Caliente el aceite de oliva en una olla y acitrone la cebolla y el ajo; agregue las zanahorias y saltee hasta que se doren ligeramente. Añada los camarones y el jitomate y deje hervir durante 2 minutos; incorpore el vino blanco, el agua y los chiles; hierva durante 10 minutos más y retire del fuego. Licue la preparación, cuélela y regrésela a la olla. Agregue la papa, el epazote, la sal y la pimienta; deje que hierva nuevamente; retire del fuego y deseche la rama de epazote. Sirva caliente y agréguele jugo de limón al gusto.",
//        foto = R.drawable.caldo
//    ),
//    Receta(
//        nombre = "Pastel Azteca",
//        preparacion = "Precalienta el horno a 180 °C.  Calienta el aceite y fríe las tortillas ligeramente para que se suavicen. Resérvalas sobre papel absorbente.  Arma el pastel en un refractario, coloca una capa de tortillas, una capa de Salsa de chile pasilla, una capa de pollo, granos de elote, rajas de chile poblano y un poco de queso. Repite la operación 2 veces más terminando con salsa y queso.   Hornea durante 20 minutos.   Corta el pastel en porciones individuales y sirve.  ",
//        foto = R.drawable.pastel
//    ),
//    Receta(
//        nombre = "Betabel de la huerta",
//        preparacion = "Encienda un asador con anticipación, usando carbón. Ase el betabel a fuego directo hasta que la piel esté quemada. Retire la piel del betabel y córtelo en cubos. Procese el betabel con el resto de los ingredientes hasta obtener un puré terso, cuélelo y divídalo en 2 partes iguales.",
//        foto = R.drawable.sacher
//    )
//)