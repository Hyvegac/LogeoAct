package com.example.logeo.navegation


sealed class AppNav (
    val route: String) {
    object Registration : AppNav (route = "registrationScreen")
    object Login : AppNav (route = "LoginScreen/{email}"){
        fun createRouteNew(email: String):String{
            return "loginScreen/$email"
        }
    }
    object HomeScreen :AppNav(route = "homeScreen/{email}"){
        fun createRoute(email: String):String{
            return "loginScreen/$email"
        }
    }
}