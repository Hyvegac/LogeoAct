package com.example.logeo.models
//
//data class Receta(
//    var nombre :String,
//    var preparacion :String,
//    var foto : Int
//)