package com.example.logeo.screen

import androidx.compose.foundation.layout.*
import androidx.compose.material.Button
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.logeo.navegation.AppNav

@Composable
fun HomeScreen (navController: NavController, email: String){
    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement =  Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(text = "PAGINA PRINCIPAL $email")
        Spacer(modifier = Modifier.size(6.dp))
        Button(
            onClick = { navController.navigate(AppNav.Login.route) },
            modifier = Modifier
                .width(280.dp)
                .height(50.dp)
        ){
            Text(text = "IR A LA PAGINA")
        }
    }
}