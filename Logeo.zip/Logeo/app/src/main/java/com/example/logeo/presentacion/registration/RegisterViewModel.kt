package com.example.logeo.presentacion.registration

import android.provider.ContactsContract.CommonDataKinds.Email
import android.util.Patterns
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.logeo.R
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class RegisterViewModel: ViewModel() {
    val state : MutableState<RegisterState> = mutableStateOf( RegisterState())
    fun register(
        nameValue: String,
        emailValue: String,
        phoneNumber: String,
        passValue : String,
        confirmPassword: String
    ){
        val errorMessages = if (nameValue.isBlank() || emailValue.isBlank() ||
            phoneNumber.isBlank() || passValue.isBlank() || confirmPassword.isBlank()){
            R.string.error_input_empy
        }else if (!Patterns.PHONE.matcher(phoneNumber).matches()){
            R.string.error_not_e_phone_number
        }else if ( !Patterns.EMAIL_ADDRESS.matcher(emailValue).matches()){
            R.string.error_not_e_valid_email
        }else if ( passValue != confirmPassword){
            R.string.error_incorrectly_repeated_password
        }else if ( nameValue !="Heidy" || emailValue !="heidy@gmail.com" || phoneNumber !="321" || passValue != "123" || confirmPassword !="123"){
            R.string.error_invalid_credentials
        }else null
        errorMessages?.let {
            state.value = state.value.copy( errorMessages = errorMessages)
            return
        }
        viewModelScope.launch{
            state.value = state.value.copy(displayProgressBar = true)
            delay(3000)
            state.value = state.value.copy( displayProgressBar = true)
        }
    }//Fin de la funcion
    fun hideErrorDialog(){
        state.value = state.value.copy( errorMessages = null )
    }
}//Fin de la clase